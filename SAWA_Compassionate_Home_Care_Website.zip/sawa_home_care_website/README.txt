SAWA COMPASSIONATE HOME CARE LLC WEBSITE

Files:
- index.html: complete responsive website
- assets/sawa-flyer.jpg: flyer image supplied for the site

PREVIEW:
Open index.html in a web browser.

FREE PUBLISHING OPTION (GitHub Pages):
1. Create or sign in to a free GitHub account at https://github.com
2. Create a new public repository, for example: sawa-home-care-website
3. Upload index.html and the assets folder (keep the folder structure unchanged).
4. In the repository, open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select the main branch and /(root), then Save.
7. GitHub will provide a free public website address after publishing.

IMPORTANT:
- The phone numbers and email are linked for calling and emailing.
- The inquiry link opens the visitor's own email app; it does not store or submit form data to a server.
- The website uses only details shown on the supplied flyer. Please review all wording and contact details before publishing.
- A custom domain name is optional and generally costs extra.
